package EmilianoGarciaParcial1_125;

public interface Podable {
    void podar();
}
