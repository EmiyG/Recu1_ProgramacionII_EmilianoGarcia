package EmilianoGarciaParcial1_125;

import java.util.Objects;

public class Planta {
    private String nombre;
    private String ubicacion;
    private String clima;

    public Planta(String nombre, String ubicacion, String clima) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Planta other = (Planta) obj;
        return nombre.equals(other.nombre) &&
               ubicacion.equals(other.ubicacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, ubicacion);
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + " Ubicacion: " + ubicacion + " Clima: " + clima;
    }
}