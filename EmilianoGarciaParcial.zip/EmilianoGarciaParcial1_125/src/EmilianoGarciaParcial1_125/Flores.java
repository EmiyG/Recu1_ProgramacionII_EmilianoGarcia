package EmilianoGarciaParcial1_125;

public class Flores extends Planta{
    private Clima tempFlorecimiento;

    public Flores(Clima tempFlorecimiento, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        this.tempFlorecimiento = tempFlorecimiento;
    }

    @Override
    public String toString() {
        String cadena = tempFlorecimiento.name();
        return super.toString() + " TempFlorecimiento: " + cadena.substring(0,1) + cadena.substring(1).toLowerCase();
    }
    
}
