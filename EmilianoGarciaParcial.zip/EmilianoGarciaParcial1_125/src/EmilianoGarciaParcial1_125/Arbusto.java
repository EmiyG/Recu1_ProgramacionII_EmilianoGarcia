package EmilianoGarciaParcial1_125;

public class Arbusto extends Planta implements Podable {
    private static final int MAX_DENSIDAD = 10;
    private static final int MIN_DENSIDAD = 1;
    private int densidadFollaje;

    public Arbusto(int densidadFollaje, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        this.densidadFollaje = valoresDensidadPermitidos(densidadFollaje);
    }

    @Override
    public void podar() {
        System.out.println("El arbusto ha sido podado.");
    }

    private int valoresDensidadPermitidos(int densidad) {
        if (densidad >= MIN_DENSIDAD && densidad <= MAX_DENSIDAD) {
            return densidad;
        }
        throw new IllegalArgumentException("Densidad debe estar entre 1 y 10");
    }

    @Override
    public String toString() {
        return super.toString() + " Densidad: " + densidadFollaje;
    }
}
